// ucl_paramters.hpp
/* This header file is used to define constants for compiling the UCL solar radiation pressure tools.  
The values should not be changed unless a new grid file has been produced.
Created January 4, 2013.
*/

#ifndef _UCL_PARAMETERS_H_
#define _UCL_PARAMETERS_H_

// Math parameters:
const double PI = 3.14159265358979;
const double rad2deg=180.0/PI; // convert radians to degrees
const double deg2rad=PI/180.0; // convert degrees to radians
const double oneAU=149597870.691; // one Astronomical Unit (km)
const double SpeedOfLight = 299792458.0; // ms^-2
const double sigmaSB = 5.670373E-8; // Stefan-Boltmann constant (Wm^-2K^-4)

// Grid File parameters:
const int gridRows = 181;
const int gridCols = 361;
const double minLATITUDE = -90.0;
const double maxLATITUDE = 90.0;
const double minLONGITUDE = -180.0;
const double maxLONGITUDE = 180.0;

#endif
