

// created 4 June 2013
#include "srpgrid.hpp"
using namespace std;
//#include <string>

// 1. Function for creating a dynamic matrix (heap) of doubles.
void dmatrix(double **&A, int row, int col)
{
	double ** A_2d = new double * [row];
	int i,j;
for (i=0; i < row; ++i)
	A_2d[i] = new double [col];
	A = A_2d;

	for(i=0; i<row; i++)
	{
		for(j=0; j<col; j++)
		{
			A[i][j] = 0.0;
		}
	}
}

// 2. Function for freeing memory when finished.
void free_dmatrix(double **A, int row)
{
	for(int i = 0; i < row; i++)
	{
		delete [] (double*) A[i];
	}
	delete [] A;
	A = NULL;
}



// 3. Function for loading a Surfer6 ascii grid file and storing it in memory.
bool loadSRPgrid(std::string filename, double **data)
{
	// FILE IO:
	// std::ifstream gridFile(filename.c_str(), std::ios::in); // input stream
	std::ifstream gridFile;
	gridFile.open(filename.c_str());
	
	if (gridFile.fail())
	{
		std::cerr << "Error opening " << filename << std::endl;
		return 0;	
	}	
	int nCols, nRows; // number of horizontal and vertical grid nodes.
	double minLon, maxLon, minLat, maxLat, minAcc, maxAcc; // x,y,z grid ranges.
	int i, j; 
	// First header line:
	std::string scrap; 
	getline(gridFile, scrap); // DSAA designation from Surfer6 format.

	// Check grid resolution:
	gridFile >> nCols;
	gridFile >> nRows;
	if ( !( nCols == gridCols ) )
	{
		std::cerr << "Expect 361 columns and detected " << nCols << " in " << filename << std::endl;
		return false;
	}
	if ( !( nRows == gridRows ) )
	{
		std::cerr << "Expected 181 columns and detected " << nRows << " in " << filename << std::endl;
		return false;
	}	
	// Check grid value ranges:
	gridFile >> minLon;
	gridFile>> maxLon;
	if ( !( minLon == minLONGITUDE ) )
	{
		std::cerr << "Expected minimum longitude of -180 and detected " << minLon << std::endl;
		return false;
	}
	if ( !( maxLon == maxLONGITUDE ) )
	{
		std::cerr << "Expected maximum longitude of 180 and detected " << maxLon << std::endl;
		return false;
	}
	gridFile >> minLat;
	gridFile >> maxLat;
	if ( !( minLat == minLATITUDE ) )
	{
		std::cerr << "Expected minimum latitude of -90 and detected " << minLat << std::endl;
		return false;
	}
	if ( !( maxLat == maxLATITUDE ) )
	{
		std::cerr << "Expected maximum latitude of 90 and deteced " << maxLat << std::endl;
		return false;
	}
	gridFile >> minAcc;	
	gridFile >> maxAcc;

	// Read in grid node values.
	for (i = 0; i < nRows; i++) // populate grid with decreasing row index - maintaining the Surfer6 format (upside Mercator).
	{
		for (j = 0; j < nCols; j++)
		{
			gridFile >> data[i][j]; // 
		}
	}
	gridFile.close(); // done with file.
	return true; // successful loading.
} // End of loadSRPgrid.

// 4. Function for performing bilinear interpolation. 
double bilinearSRP(double longitude, double latitude, double **data)
{	
	// Check input for validity.
	if ( (longitude < -180) || (longitude > 180) )
	{
		std::cerr << "Longitude value (" << longitude << ") out of range" << std::endl;
	}
	if ( (latitude < -90) || (latitude > 90) )
	{
		std::cerr << "Latitude value (" << latitude << ") out of range" << std::endl;
	}

	// Calculate grid spacing based on expected values.
	double deltaX = (maxLONGITUDE - minLONGITUDE) / (gridCols - 1); // horizontal grid spacing.
	double deltaY = (maxLATITUDE - minLATITUDE) / (gridRows - 1); // vertical grid spacing.
	double xraw = (( longitude - minLONGITUDE) / deltaX ); // raw horizontal index in array (0 indexing).
	double yraw = (( latitude - minLATITUDE) / deltaY ); // raw vertical index in array (0 indexing).

	// Perform interpolation based on appropriate neighbors:
	if ( floor(xraw) == xraw && floor(yraw) == yraw ) // Interpolation point falls on grid node exactly:
	{
		int i = (int) floor(yraw); // integer type of vertical index.
		int j = (int) floor(xraw); // integer type of horizontal index.
		return data[i][j]; // retrieve array value directly.  
	}
	else if ( floor(yraw) == yraw ) // Interpolation point falls on horizontal grid line:
	{
		int i = (int) floor(yraw); // integer type of vertical index.
		int j1 = (int) floor(xraw);
		int j2 = j1 + 1;
		//std::cout << j1 << endl;
		//std::cout << j2 << endl;
		
		double x1 = minLONGITUDE + j1*deltaX; // left neighbor.
		double x2 = minLONGITUDE + j2*deltaX; // right neighbor.
		double f1 = data[i][j1];
		double f2 = data[i][j2];
		double z = ( (f2 - f1)/(x2 - x1) )*(longitude - x1) + f1; // 1D rightward interpolation.
		return z;
	}
	else if ( floor(xraw) == xraw ) // Interpolation point falls on vertical grid line:
	{
		int j = (int) floor(xraw);
		int i1 = (int) floor(yraw);
		int i2 = i1 + 1;
		// std::cout << i1 << endl;
		// std::cout << i2 << endl;
		
		double y1 = minLATITUDE + i1*deltaY; // upper neighbor.
		double y2 = minLATITUDE + i2*deltaY; // lower neighbor.
		double f1 = data[i1][j];
		double f2 = data[i2][j];
		double z = ( (f2 - f1)/(y2 - y1) )*(latitude - y1) + f1; // 1D downward interpolation (increasing latitude).
		return z;
	}
	else // Interpolation point falls inbetween grid points in both directions:
	{
		int j1 = (int) floor(xraw);
		int j2 = j1 + 1;
		double x1 = minLONGITUDE + j1*deltaX;
		double x2 = minLONGITUDE + j2*deltaX;
		
		int i1 = (int) floor(yraw);
		int i2 = i1 + 1;
		double y1 = minLATITUDE + i1*deltaY;
		double y2 = minLATITUDE + i2*deltaY;
		
		double fll = data[i2][j1]; // lower left corner value.
		double flr = data[i2][j2]; // lower right corner value.
		double ful = data[i1][j1]; // uppper left corner value.
		double fur = data[i1][j2]; // upper right corner value.
		
		double R1 = ( (fur - ful)/(x2 - x1) )*(longitude - x1) + ful; // horizontal interpolation along upper border.
		double R2 = ( (flr - fll)/(x2 - x1) )*(longitude - x1) + fll; // horizontal interpolation along lower border.
		double z = ( (R2 - R1)/(y2 - y1) )*(latitude - y1) + R1; // vertical interpolation (downward) between R1 and R2.
		return z;
	}
} // End of bilinearSRP.

