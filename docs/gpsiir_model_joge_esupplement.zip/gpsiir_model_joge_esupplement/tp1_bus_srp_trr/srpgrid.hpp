
// created 4 June 2013

#ifndef SRPGRIDh
#define SRPGRIDh

#include "ucl_parameters.hpp"
#include <string>
#include <iostream>
#include <fstream>
#include <cmath>

//namespace ucl {

	void dmatrix(double **&A, int row, int col); //create dynamic array of doubles
	void free_dmatrix(double **A, int row); //release 2d array memory when finished


	// Function for loading a UCL SRP grid file into dynamic memory.  It relies on the dmatrix functions in matrix.cpp.  It uses a filepath to parse a Surfer6 ascii grid file and load the dmatrix elements.  
	// This should be called in the main program so that it happens once, outside of integration loops.  It should also be cleaned up at the end of the program.
	// This maintains the surfer6 orientation - an upside Mercator.
	bool loadSRPgrid(std::string filepath, double **data); // load grid file values into previously initialized dynamic matrix of appropriate dimensions.

	// Function for performing bilinear interpolation on a dmatrix SRP array.  
	// This should be called from a function which computes the solar radiation pressure, e.g., GPS_SRP.  
	// This function expects an upside Mercator orientation, where row index corresponds to increasing latitude.  
	double bilinearSRP(double lon, double lat, double **data); // bilinearly interpolate to the point (lon,lat) using the value stored in data.

//};

#endif


