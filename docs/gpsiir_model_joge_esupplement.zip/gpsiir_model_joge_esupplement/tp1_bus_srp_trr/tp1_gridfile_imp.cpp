
// tp1_gridfile_imp.cpp
// This file is a test of basic grid file loading and interpolation.

#include <iomanip>
#include "srpgrid.hpp"
using namespace std; // tired of typing std:: ?

int main () 
{
	cout << "Test1: Test program for grid file interpolation" << endl;
	cout << "Space Geodesy and Navigation Lab" << endl;
	cout << "University College London" << endl;
	cout << "This test loads the three grid files and performs various interpolations. " << endl;
	cout << "The results are written to 'ucl_gridfile_imp_test1.txt'." << endl;
	
	std::ofstream outFile("ucl_test1.txt", ios::out); // output file stream
	//FILE *outFile; // output file pointer.

	// Load grid files:
	string xSRP_file, ySRP_file, zSRP_file; // filenames

	xSRP_file = "../grids/no_nap_antenna/gpsiirX-R100-Q34W13S0.grd"; // x-component of bus SRP acceleration.
	ySRP_file = "../grids/no_nap_antenna/gpsiirY-R100-Q50W50S0.grd"; // y-component of bus SRP acceleration.
	zSRP_file = "../grids/no_nap_antenna/gpsiirZ-R100-Q32W11S0.grd"; // z-component of bus SRP acceleration.

	// xSRP_file = "../grids/nap_antenna/gpsiirnapX-R100-Q37W13S0.grd"; // x-component of bus SRP acceleration.
	// ySRP_file = "../grids/nap_antenna/gpsiirnapY-R100-Q50W50S0.grd"; // y-component of bus SRP acceleration.
	// zSRP_file = "../grids/nap_antenna/gpsiirnapZ-R100-Q32W11S0.grd"; // z-component of bus SRP acceleration.
	
	double **xSRPgrid, **ySRPgrid, **zSRPgrid; // pointers to type double for dynamic arrays.
	dmatrix(xSRPgrid, 181, 361); // reserve memory and initialize to 0's.
	dmatrix(ySRPgrid, 181, 361); // reserve memory and initialize to 0's.
	dmatrix(zSRPgrid, 181, 361); // reserve memory and initialize to 0's.
	
	if (loadSRPgrid(xSRP_file, xSRPgrid) ) // load the x-gridfile into array.
		{ cout << "x SRP acceleration successfully loaded." << endl;}
	else {cerr << "Error loading x acceleration." << endl;}
	if (loadSRPgrid(ySRP_file, ySRPgrid) ) // load the y-gridfile into array.
		{ cout << "y SRP acceleration successfully loaded." << endl;}
	else {cerr << "Error loading y acceleration." << endl;}
	if (loadSRPgrid(zSRP_file, zSRPgrid) ) // load the z-gridfile into array.
		{ cout << "z SRP acceleration successfully loaded." << endl;}
	else {cerr << "Error loading z acceleration." << endl;}
	
	// Check grid file corner values:
	double xCorners[4], yCorners[4], zCorners[4];
	xCorners[0] = bilinearSRP(-180, 90, xSRPgrid); // lower left of grid.
	xCorners[1] = bilinearSRP(180, 90, xSRPgrid); // lower right of grid.
	xCorners[2] = bilinearSRP(-180, -90, xSRPgrid); // upper left of grid.
	xCorners[3] = bilinearSRP(180, -90, xSRPgrid); // upper right of grid.

	yCorners[0] = bilinearSRP(-180, 90, ySRPgrid); // lower left of grid.
	yCorners[1] = bilinearSRP(180, 90, ySRPgrid); // lower right of grid.
	yCorners[2] = bilinearSRP(-180, -90, ySRPgrid); // upper left of grid.
	yCorners[3] = bilinearSRP(180, -90, ySRPgrid); // upper right of grid.
	
	zCorners[0] = bilinearSRP(-180, 90, zSRPgrid); // lower left of grid.
	zCorners[1] = bilinearSRP(180, 90, zSRPgrid); // lower right of grid.
	zCorners[2] = bilinearSRP(-180, -90, zSRPgrid); // upper left of grid.
	zCorners[3] = bilinearSRP(180, -90, zSRPgrid); // upper right of grid.
	/*
	cout << endl << "Corner values of grid files: " << endl;
	cout << "X values: " << endl;
	cout << setprecision(16) << xCorners[2] << "\t" << xCorners[3] << endl;
	cout << xCorners[0] << "\t" << xCorners[1] << endl;
	cout << "Y values: " << endl;
	cout << setprecision(16) << yCorners[2] << "\t" << yCorners[3] << endl;
	cout << yCorners[0] << "\t" << yCorners[1] << endl;
	cout << "Z values: " << endl;
	cout << setprecision(16) << zCorners[2] << "\t" << zCorners[3] << endl;
	cout << zCorners[0] << "\t" << zCorners[1] << endl;
	*/
	outFile << setprecision(16)
			<< "\n X[-180][-90] = " << xCorners[2]
			<< "\n X[180][-90] = " << xCorners[3]
			<< "\n X[-180][90] = " << xCorners[0]
			<< "\n X[180][90] = " << xCorners[1]
			<< "\n\n Y[-180][-90] = " << yCorners[2]
			<< "\n Y[180][-90] = " << yCorners[3]
 			<< "\n Y[-180][90] = " << yCorners[0]			
			<< "\n Y[180][90] = " << yCorners[1]
			<< "\n\n Z[-180][-90] = " << zCorners[2]
			<< "\n Z[180][-90] = " << zCorners[3]
 			<< "\n Z[-180][90] = " << zCorners[0]			
			<< "\n Z[180][90] = " << zCorners[1]
			<< "\n"<< std::endl;

	// Check pole values:
	double xNP, xSP, yNP, ySP, zNP, zSP; // north and south poles of x,y,z grids.
	xNP = bilinearSRP(0.0, 90, xSRPgrid); 
	xSP = bilinearSRP(0.0, -90, xSRPgrid); 
	yNP = bilinearSRP(0.0, 90, ySRPgrid); 
	ySP = bilinearSRP(0.0, -90, ySRPgrid); 
	zNP = bilinearSRP(0.0, 90, zSRPgrid); 
	zSP = bilinearSRP(0.0, -90, zSRPgrid); 
	
	
	outFile << "X north pole (0,90) = " << setprecision(16) << xNP << std::endl;
	outFile << "X south pole (0,-90) = " << setprecision(16) << xSP << std::endl;
	outFile << "Y north pole (0,90) = " << setprecision(16) << yNP << std::endl;
	outFile << "Y south pole (0,-90) = " << setprecision(16) << ySP << std::endl;
	outFile << "Z north pole (0,90) = " << setprecision(16) << zNP << std::endl;
	outFile << "Z south pole (0,-90) = " << setprecision(16) << zSP << std::endl;	
	
		
	// 1D horizontal interpolation:
	double xH, yH, zH;
	xH = bilinearSRP(36.27, -48.0, xSRPgrid);
	yH = bilinearSRP(36.27, -48.0, ySRPgrid);
	zH = bilinearSRP(36.27, -48.0, zSRPgrid);
	
	outFile << endl << "Horizontal Interpolation:" << endl;
	outFile << "Interpolating x grid to (36.27, -48.0) = " << bilinearSRP(36.27, -48.0, xSRPgrid) << std::endl;
	outFile << "Interpolating y grid to (36.27, -48.0) = " << bilinearSRP(36.27, -48.0, ySRPgrid) << std::endl;
	outFile << "Interpolating z grid to (36.27, -48.0) = " << bilinearSRP(36.27, -48.0, zSRPgrid) << std::endl;
	
	
	// 1D vertical interpolation:
	double xV, yV, zV;
	xV = bilinearSRP(37.0, 68.35, xSRPgrid);
	yV = bilinearSRP(37.0, 68.35, ySRPgrid);
	zV = bilinearSRP(37.0, 68.35, zSRPgrid);
	
	outFile << std::endl << "Vertical Interpolation:" << std::endl;
	outFile << "Interpolating x grid to (37, 68.35) = " << bilinearSRP(37.0, 68.35, xSRPgrid) << std::endl;
	outFile << "Interpolating y grid to (37, 68.35) = " << bilinearSRP(37.0, 68.35, ySRPgrid) << std::endl;
	outFile << "Interpolating z grid to (37, 68.35) = " << bilinearSRP(37.0, 68.35, zSRPgrid) << std::endl;
	
	// Bilinear interpolation.
	// double lonPoint1 = -0.1275;
	// double latPoint1 = 51.5072;
    double lonPoint1 = -51.817174;
	double latPoint1 = -25.330074;
	double lonPoint2 = -106.61;
	double latPoint2 = 35.1108;
	double lonPoint3 = 180;
	double latPoint3 = 50;
	double lonPoint4 = -2.538516462;
	double latPoint4 = -9.990384523;
	
	double xpoint1 = bilinearSRP(lonPoint1, latPoint1, xSRPgrid);
	double ypoint1 = bilinearSRP(lonPoint1, latPoint1, ySRPgrid);
	double zpoint1 = bilinearSRP(lonPoint1, latPoint1, zSRPgrid);

	double xpoint2 = bilinearSRP(lonPoint2, latPoint2, xSRPgrid);
	double ypoint2 = bilinearSRP(lonPoint2, latPoint2, ySRPgrid);
	double zpoint2 = bilinearSRP(lonPoint2, latPoint2, zSRPgrid);

	double xpoint3 = bilinearSRP(lonPoint3, latPoint3, xSRPgrid);
	double ypoint3 = bilinearSRP(lonPoint3, latPoint3, ySRPgrid);
	double zpoint3 = bilinearSRP(lonPoint3, latPoint3, zSRPgrid);

	double xpoint4 = bilinearSRP(lonPoint4, latPoint4, xSRPgrid);
	double ypoint4 = bilinearSRP(lonPoint4, latPoint4, ySRPgrid);
	double zpoint4 = bilinearSRP(lonPoint4, latPoint4, zSRPgrid);
		
	outFile << endl;
	outFile << "Interpolating x grid to (" << lonPoint1 << ", " << latPoint1 << ") = " << xpoint1 << endl;
	outFile << "Interpolating y grid to (" << lonPoint1 << ", " << latPoint1 << ") = " << ypoint1 << endl;
	outFile << "Interpolating z grid to (" << lonPoint1 << ", " << latPoint1 << ") = " << zpoint1 << endl;

	outFile << "Interpolating x grid to (" << lonPoint2 << ", " << latPoint2 << ") = " << xpoint2 << endl;
	outFile << "Interpolating y grid to (" << lonPoint2 << ", " << latPoint2 << ") = " << ypoint2 << endl;
	outFile << "Interpolating z grid to (" << lonPoint2 << ", " << latPoint2 << ") = " << zpoint2 << endl;

	outFile << "Interpolating x grid to (" << lonPoint3 << ", " << latPoint3 << ") = " << xpoint3 << endl;
	outFile << "Interpolating y grid to (" << lonPoint3 << ", " << latPoint3 << ") = " << ypoint3 << endl;
	outFile << "Interpolating z grid to (" << lonPoint3 << ", " << latPoint3 << ") = " << zpoint3 << endl;

	outFile << "Interpolating x grid to (" << lonPoint4 << ", " << latPoint4 << ") = " << xpoint4 << endl;
	outFile << "Interpolating y grid to (" << lonPoint4 << ", " << latPoint4 << ") = " << ypoint4 << endl;
	outFile << "Interpolating z grid to (" << lonPoint4 << ", " << latPoint4 << ") = " << zpoint4 << endl;

	//Test output for the manual bilinear computation

	// Bilinear interpolation.
	double mlonPoint1 = -2;
	double mlatPoint1 = -9;
	double mlonPoint2 = -3;
	double mlatPoint2 = -9;
	double mlonPoint3 = -2;
	double mlatPoint3 = -10;
	double mlonPoint4 = -3;
	double mlatPoint4 = -10;
	
	double mxpoint1 = bilinearSRP(mlonPoint1, mlatPoint1, xSRPgrid);
	double mypoint1 = bilinearSRP(mlonPoint1, mlatPoint1, ySRPgrid);
	double mzpoint1 = bilinearSRP(mlonPoint1, mlatPoint1, zSRPgrid);

	double mxpoint2 = bilinearSRP(mlonPoint2, mlatPoint2, xSRPgrid);
	double mypoint2 = bilinearSRP(mlonPoint2, mlatPoint2, ySRPgrid);
	double mzpoint2 = bilinearSRP(mlonPoint2, mlatPoint2, zSRPgrid);

	double mxpoint3 = bilinearSRP(mlonPoint3, mlatPoint3, xSRPgrid);
	double mypoint3 = bilinearSRP(mlonPoint3, mlatPoint3, ySRPgrid);
	double mzpoint3 = bilinearSRP(mlonPoint3, mlatPoint3, zSRPgrid);

	double mxpoint4 = bilinearSRP(mlonPoint4, mlatPoint4, xSRPgrid);
	double mypoint4 = bilinearSRP(mlonPoint4, mlatPoint4, ySRPgrid);
	double mzpoint4 = bilinearSRP(mlonPoint4, mlatPoint4, zSRPgrid);
		
	outFile << endl;
	outFile << "Interpolating x grid to (" << mlonPoint1 << ", " << mlatPoint1 << ") = " << mxpoint1 << endl;
	//outFile << "Interpolating y grid to (" << mlonPoint1 << ", " << mlatPoint1 << ") = " << mypoint1 << endl;
	//outFile << "Interpolating z grid to (" << mlonPoint1 << ", " << mlatPoint1 << ") = " << mzpoint1 << endl;

	outFile << "Interpolating x grid to (" << mlonPoint2 << ", " << mlatPoint2 << ") = " << mxpoint2 << endl;
	//outFile << "Interpolating y grid to (" << mlonPoint2 << ", " << mlatPoint2 << ") = " << mypoint2 << endl;
	//outFile << "Interpolating z grid to (" << mlonPoint2 << ", " << mlatPoint2 << ") = " << mzpoint2 << endl;

	outFile << "Interpolating x grid to (" << mlonPoint3 << ", " << mlatPoint3 << ") = " << mxpoint3 << endl;
	//outFile << "Interpolating y grid to (" << mlonPoint3 << ", " << mlatPoint3 << ") = " << mypoint3 << endl;
	//outFile << "Interpolating z grid to (" << mlonPoint3 << ", " << mlatPoint3 << ") = " << mzpoint3 << endl;

	outFile << "Interpolating x grid to (" << mlonPoint4 << ", " << mlatPoint4 << ") = " << mxpoint4 << endl;
	//outFile << "Interpolating y grid to (" << mlonPoint4 << ", " << mlatPoint4 << ") = " << mypoint4 << endl;
	//outFile << "Interpolating z grid to (" << mlonPoint4 << ", " << mlatPoint4 << ") = " << mzpoint4 << endl;
	
	outFile.close();
	// Release memory:
	free_dmatrix(xSRPgrid, 181); cout << "x SRP grid memory released." << endl;
	free_dmatrix(ySRPgrid, 181); cout << "y SRP grid memory released." << endl;
	free_dmatrix(zSRPgrid, 181); cout << "z SRP grid memory released." << endl;
	
	return 0;
}

